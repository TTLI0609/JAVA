package pobj.tme5;

public class MultiSetParserTest {

	public static void main(String[] args) throws InvalidMultiSetFormat {
		
		
		System.out.println(MultiSetParser.parse("ParserTest.txt").toString());
		
	}

}
