package pobj.pinboard.editor;

public interface ClipboardListener {
	public void clipboardChanged();
}

